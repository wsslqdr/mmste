<template>
  <div>
    <h1>欢迎访问外联部信息管理系统</h1>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
div {
  text-align: center;
}
</style>
